function setup() {
  createCanvas(700, 480);
  
  //R,G and B values.
  background(225,204,0);
  
  //take a big brush
  strokeWeight(30);
  //dip it in color purple
  stroke('#3C0897');
  
  //place a dot on the screen
  point(700/2,480/2);
}
function draw () {}